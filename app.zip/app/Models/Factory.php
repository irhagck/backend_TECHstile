<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Factory extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'address',
        'city',
    ];

    public function manager()
{
    return $this->belongsTo(
        User::class,
        'manager_id'
    );
}
}