<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('factories', function (Blueprint $table) {
            // 0 = Sunday ... 6 = Saturday (matches Carbon's dayOfWeek numbering)
            $table->unsignedTinyInteger('week_start_day')->default(1)->after('city');
        });
    }

    public function down(): void
    {
        Schema::table('factories', function (Blueprint $table) {
            $table->dropColumn('week_start_day');
        });
    }
};
